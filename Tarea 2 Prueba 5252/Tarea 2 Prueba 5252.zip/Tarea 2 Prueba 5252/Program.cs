﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea_2_Prueba_5252
{
    class Program
    {

        static void Main(string[] args)
        {

            Menu opciones = new Menu();
            Menu2 segunda_opcion = new Menu2();
            Menu3 tercera_opcion = new Menu3();
            Menu4 cuarta_opcion = new Menu4();
            int op=0;

            while (op != 4)
            {


                Console.Clear();
                Console.WriteLine("----------------");
                Console.WriteLine("Menu Min & Asoc.");
                Console.WriteLine("-----------------");
                Console.WriteLine("1. Empleados");
                Console.WriteLine("2. Producto");
                Console.WriteLine("3. Inventario");
                Console.WriteLine("4. Ventas");
                Console.WriteLine("5. Salir");
                Console.WriteLine("------------");
                op = Convert.ToInt32(Console.ReadLine());

                switch (op = 1)
                {
                    case 1:
                        {
                            opciones.leer();
                            Console.ReadLine();
                        }
                        break;

                    case 2:
                        {
                            opciones.mostrar();
                            Console.ReadLine();
                        }
                        break;

                    case 3:
                        {
                            Console.WriteLine("Ingrese su codigo a buscar");
                            string codigo_empleado = Console.ReadLine();
                            opciones.buscar(codigo_empleado);
                        }
                        break;

                    case 4:
                        {
                            Console.WriteLine("Atras");
                            Console.ReadKey();
                        }
                        break;
                }

                switch (op = 2)
                {
                    case 1:
                        {
                            segunda_opcion.ingresar();
                            Console.ReadLine();
                        }
                        break;

                    case 2:
                        {
                            segunda_opcion.visualizar();
                            Console.ReadLine();
                        }
                        break;

                    case 3:
                        {
                            Console.WriteLine("Ingrese su codigo a buscar");
                            string codigo_producto = Console.ReadLine();
                            segunda_opcion.bs(codigo_producto);
                        }
                        break;

                    case 4:
                        {
                            Console.WriteLine("Atras");
                            Console.ReadKey();
                        }
                        break;
                }

                switch (op = 3)
                {
                    case 1:
                        {
                            tercera_opcion.administrar();
                            Console.ReadLine();
                        }
                        break;

                    case 2:
                        {
                            tercera_opcion.consultar();
                            Console.ReadLine();
                        }
                        break;

                    case 3:
                        {
                            Console.WriteLine("Ingrese su codigo a buscar");
                            string proveedor = Console.ReadLine();
                            tercera_opcion.ts(proveedor);
                        }
                        break;

                    case 4:
                        {
                            Console.WriteLine("Atras");
                            Console.ReadKey();
                        }
                        break;

                }

                switch (op = 4)
                {
                    case 1:
                        {
                            cuarta_opcion.preventa();
                            Console.ReadLine();
                        }
                        break;

                    case 2:
                        {
                            cuarta_opcion.producto_Vendido();
                            Console.ReadLine();
                        }
                        break;

                    case 3:
                        {
                            Console.WriteLine("Ingrese su codigo a buscar");
                            string producto = Console.ReadLine();
                            cuarta_opcion.bs(producto);
                        }
                        break;

                    case 4:
                        {
                            Console.WriteLine("Atras");
                            Console.ReadKey();
                        }
                        break;





                }


            }
        }
    }
}
